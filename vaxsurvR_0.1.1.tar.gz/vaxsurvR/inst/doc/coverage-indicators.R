## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----setup--------------------------------------------------------------------
library(vaxsurvR)

## -----------------------------------------------------------------------------
vcs_evidence_levels()

## -----------------------------------------------------------------------------
vcs_evidence_definitions()

## -----------------------------------------------------------------------------
graded <- derive_evidence(vcs_example)
table(graded$vaccinations$evidence)

## -----------------------------------------------------------------------------
defs <- c("card", "card_date", "recall", "card_or_recall")
results <- lapply(defs, function(e) {
  d <- derive_vaccination_status(vcs_example, evidence = e)
  est <- estimate_coverage(vcs_design(d), vaccines = "PENTA1")
  data.frame(evidence = e, estimate = round(est$estimate, 3),
             denominator = est$denominator)
})
do.call(rbind, results)

## -----------------------------------------------------------------------------
forced <- derive_vaccination_status(vcs_example, evidence = "card",
                                    missing_as_unvaccinated = TRUE)
subset(derivation_rules(forced), variable == "cov_PENTA1")$rule

## -----------------------------------------------------------------------------
estimate_coverage_by_evidence(vcs_example, vaccines = c("BCG", "PENTA3", "MCV1"))

## -----------------------------------------------------------------------------
estimate_coverage_by_evidence(vcs_example, vaccines = "PENTA3",
                              denominator = "determinable")

## -----------------------------------------------------------------------------
d   <- derive_vaccination_status(vcs_example, evidence = "card_or_recall")
des <- vcs_design(d)

estimate_coverage(des, vaccines = c("BCG", "PENTA1", "PENTA2", "PENTA3",
                                    "MCV1"))

## -----------------------------------------------------------------------------
estimate_coverage(des, vaccines = "MCV1", by = ~stratum)

## -----------------------------------------------------------------------------
schedule_final_doses(vcs_example_schedule)

## -----------------------------------------------------------------------------
full <- derive_fully_vaccinated(vcs_example)
estimate_full_coverage(vcs_design(full))

## -----------------------------------------------------------------------------
basic <- derive_fully_vaccinated(
  vcs_example,
  vaccines = c("BCG", "PENTA3", "MCV1"),
  name     = "basic_full"
)
estimate_full_coverage(vcs_design(basic), variable = "basic_full")

## -----------------------------------------------------------------------------
subset(derivation_rules(basic), variable == "basic_full")$rule

## -----------------------------------------------------------------------------
zd <- derive_zero_dose(vcs_example)
estimate_zero_dose(vcs_design(zd), by = ~stratum)

## -----------------------------------------------------------------------------
subset(derivation_rules(zd), variable == "zero_dose")$rule

## -----------------------------------------------------------------------------
estimate_dropout(des, first = "PENTA1", last = "PENTA3", method = "coverage")

## -----------------------------------------------------------------------------
estimate_dropout(des, first = "PENTA1", last = "PENTA3", method = "individual")

## -----------------------------------------------------------------------------
estimate_dropout(des, first = "BCG", last = "MCV1", by = ~stratum)

## -----------------------------------------------------------------------------
pairs <- list(c("PENTA1", "PENTA3"), c("BCG", "MCV1"), c("PENTA1", "MCV1"))
do.call(rbind, lapply(pairs, function(p) {
  estimate_dropout(des, p[1], p[2])[, c("indicator", "estimate", "conf_low",
                                        "conf_high", "denominator")]
}))

## -----------------------------------------------------------------------------
tl <- derive_timeliness(vcs_example)
table(tl$vaccinations$timeliness, useNA = "ifany")

## -----------------------------------------------------------------------------
estimate_timely_coverage(vcs_design(tl),
                         vaccines = c("BCG", "PENTA1", "PENTA3", "MCV1"))

## -----------------------------------------------------------------------------
estimate_card_availability(vcs_design(vcs_example), by = ~stratum)

## -----------------------------------------------------------------------------
rep <- vcs_coverage_report(des,
                           vaccines = c("BCG", "PENTA1", "PENTA3", "MCV1"),
                           by = ~stratum)
rep

## -----------------------------------------------------------------------------
rep$dropout

