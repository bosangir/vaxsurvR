## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7, fig.height = 5)

## ----setup--------------------------------------------------------------------
library(vaxsurvR)

## -----------------------------------------------------------------------------
qa <- validate_vcs(vcs_example)
qa

## -----------------------------------------------------------------------------
vcs_severities()

## -----------------------------------------------------------------------------
summary(qa, by = "severity")

## -----------------------------------------------------------------------------
summary(qa, by = "rule")

## -----------------------------------------------------------------------------
plot(qa)

## -----------------------------------------------------------------------------
summary(check_unique_ids(vcs_example))

## -----------------------------------------------------------------------------
issues(check_psu_structure(vcs_example))

## -----------------------------------------------------------------------------
summary(check_child_eligibility(vcs_example, min_age_months = 12,
                                max_age_months = 23))

## -----------------------------------------------------------------------------
parse_vaccine_date(c("2025-03-14", "2025-03", "2025", "", "31/02/2025",
                     "vu sur carte"))

## -----------------------------------------------------------------------------
p <- parse_vaccine_date(c("2025-03-14", "2025-02", "2025"))
validate_partial_date(p)                                   # default: none
validate_partial_date(p, rule = "midpoint")
validate_partial_date(p, rule = "midpoint", min_precision = "year")

## -----------------------------------------------------------------------------
issues(check_prebirth_vaccination(vcs_example))[1:3, c("record_id", "value", "message")]

## -----------------------------------------------------------------------------
summary(check_vaccine_sequence(vcs_example))

## -----------------------------------------------------------------------------
summary(check_dose_intervals(vcs_example))

## -----------------------------------------------------------------------------
nrow(issues(check_age_at_vaccination(vcs_example)))
nrow(issues(check_age_at_vaccination(vcs_example, tolerance_days = 7)))

## -----------------------------------------------------------------------------
summary(check_card_transcription(vcs_example))

## -----------------------------------------------------------------------------
flags <- flag_vaccine_inconsistencies(vcs_example)
head(flags)
table(flags$max_severity)

## -----------------------------------------------------------------------------
vcs_default_rules()

## -----------------------------------------------------------------------------
cleaned <- clean_vcs(vcs_example)
identical(cleaned$vaccinations$card_date, vcs_example$vaccinations$card_date)

## -----------------------------------------------------------------------------
summary(cleaned$audit)

## -----------------------------------------------------------------------------
head(audit_changes(cleaned), 3)
names(audit_changes(cleaned))

## -----------------------------------------------------------------------------
rules <- vcs_ruleset(
  vcs_rule(
    "BLANK_FUTURE_DATES",
    "Blank card dates recorded after the interview date",
    level    = "vaccination",
    where    = !is.na(card_date) & !is.na(interview_date) &
                 card_date > interview_date,
    variable = "card_date",
    action   = "set_na",
    severity = "ERROR"
  )
)

strict <- clean_vcs(vcs_example, rules = rules)
audit_changes(strict)[, c("record_id", "variable", "original_value",
                          "new_value", "rule_id")]

## -----------------------------------------------------------------------------
dry <- clean_vcs(vcs_example, rules = rules, dry_run = TRUE)
nrow(audit_changes(dry))
identical(dry$vaccinations$card_date, vcs_example$vaccinations$card_date)

## -----------------------------------------------------------------------------
f <- tempfile(fileext = ".csv")
export_cleaning_log(cleaned, f)
head(read.csv(f), 2)
unlink(f)

## -----------------------------------------------------------------------------
card_completeness(vcs_example, by = ~stratum)

## -----------------------------------------------------------------------------
head(date_completeness(vcs_example, by = ~vaccine))

## -----------------------------------------------------------------------------
head(vcs_missingness(vcs_example, variables = "card_seen", by = ~enumerator), 5)

