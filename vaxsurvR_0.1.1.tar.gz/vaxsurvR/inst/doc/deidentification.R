## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----setup--------------------------------------------------------------------
library(vaxsurvR)

## ----error = TRUE-------------------------------------------------------------
try({
hash_identifier("CH0001")
})

## -----------------------------------------------------------------------------
salt <- "vignette-salt-not-for-production"

## -----------------------------------------------------------------------------
pii <- identify_pii(vcs_example_raw, vcs_example_dictionary)
pii

## -----------------------------------------------------------------------------
hash_identifier(c("CH0001", "CH0002"), salt = salt)

## -----------------------------------------------------------------------------
identical(
  hash_identifier("CH0001", salt = salt),
  hash_identifier("CH0001", salt = salt)
)

## -----------------------------------------------------------------------------
hash_identifier("CH0001", salt = salt, namespace = "coverage")
hash_identifier("CH0001", salt = salt, namespace = "serology")

## -----------------------------------------------------------------------------
names(vcs_example$households)

## -----------------------------------------------------------------------------
d1 <- generalize_geography(vcs_example)
setdiff(names(vcs_example$households), names(d1$households))

## -----------------------------------------------------------------------------
d2 <- generalize_geography(vcs_example, round_gps = 2)
head(d2$households$gps_lat, 3)

## -----------------------------------------------------------------------------
d3 <- generalize_geography(vcs_example, lowest_level = "district", min_cell = 10)
intersect(c("province", "district", "health_zone", "health_area"),
          names(d3$households))

## -----------------------------------------------------------------------------
d4 <- generalize_age(vcs_example, breaks = c(0, 12, 18, 24, Inf))
table(d4$children$age_band, useNA = "ifany")
"child_dob" %in% names(d4$children)

## -----------------------------------------------------------------------------
shifted <- shift_dates(vcs_example, salt = salt, max_days = 30)

a <- vcs_example$vaccinations
b <- shifted$vaccinations
cid <- a$child_id[!is.na(a$card_date)][1]

data.frame(
  original = a$card_date[a$child_id == cid],
  shifted  = b$card_date[b$child_id == cid]
)

## -----------------------------------------------------------------------------
identical(
  diff(a$card_date[a$child_id == cid]),
  diff(b$card_date[b$child_id == cid])
)

## -----------------------------------------------------------------------------
anon <- deidentify_vcs(
  vcs_example,
  remove     = c("child_name", "caregiver_name", "telephone", "address"),
  hash       = c("child_id", "household_id"),
  salt       = salt,
  age_bands  = c(0, 12, 18, 24, Inf),
  geography  = list(lowest_level = "health_zone", round_gps = 2)
)
anon$deidentification$actions

## -----------------------------------------------------------------------------
anon$deidentification$salt
anon$deidentification$salt_used

## -----------------------------------------------------------------------------
head(anon$children$child_id, 3)
all(anon$vaccinations$child_id %in% anon$children$child_id)

## -----------------------------------------------------------------------------
estimate_coverage(vcs_design(derive_vaccination_status(anon)),
                  vaccines = c("BCG", "PENTA3"))

## -----------------------------------------------------------------------------
assess_reidentification_risk(vcs_example)

## -----------------------------------------------------------------------------
assess_reidentification_risk(
  generalize_geography(vcs_example, lowest_level = "province")
)

