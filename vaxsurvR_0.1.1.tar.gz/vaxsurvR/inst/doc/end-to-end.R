## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----setup--------------------------------------------------------------------
library(vaxsurvR)

## -----------------------------------------------------------------------------
schedule   <- vcs_example_schedule
dictionary <- vcs_example_dictionary
schedule

## -----------------------------------------------------------------------------
raw <- vcs_example_raw
dim(raw)

## -----------------------------------------------------------------------------
mapped <- map_vcs_variables(raw, dictionary, schedule)
mapped

## -----------------------------------------------------------------------------
qa <- validate_vcs(mapped)
summary(qa, by = "severity")

## -----------------------------------------------------------------------------
if (has_issues(qa, "CRITICAL")) {
  head(issues(qa, severity = "CRITICAL")[, c("rule_id", "record_id", "message")], 5)
}

## -----------------------------------------------------------------------------
cleaned <- clean_vcs(mapped)
summary(cleaned$audit)

## -----------------------------------------------------------------------------
log_file <- tempfile(fileext = ".csv")
export_cleaning_log(cleaned, log_file)

## -----------------------------------------------------------------------------
d <- derive_vaccination_status(cleaned, evidence = "card_or_recall")
d <- derive_fully_vaccinated(d, vaccines = c("BCG", "PENTA3", "MCV1"),
                             name = "basic_full")
d <- derive_zero_dose(d)
d <- derive_timeliness(d)

head(derivation_rules(d), 8)

## -----------------------------------------------------------------------------
salt <- "vignette-salt-not-for-production"   # in production: Sys.getenv("VAXSURVR_SALT")

anon <- deidentify_vcs(
  d,
  remove    = c("child_name", "caregiver_name", "telephone", "address"),
  hash      = c("child_id", "household_id"),
  salt      = salt,
  geography = list(lowest_level = "health_zone", round_gps = 2)
)
anon$deidentification$actions

## -----------------------------------------------------------------------------
assess_reidentification_risk(anon)

## -----------------------------------------------------------------------------
issues(validate_weights(anon))

## -----------------------------------------------------------------------------
design <- vcs_design(anon, ids = ~psu, strata = ~stratum, weights = ~weight)
design

## -----------------------------------------------------------------------------
by_evidence <- estimate_coverage_by_evidence(
  anon,
  vaccines    = c("BCG", "PENTA1", "PENTA3", "MCV1"),
  design_args = list(ids = ~psu, strata = ~stratum, weights = ~weight)
)
by_evidence[, c("indicator", "evidence", "numerator", "denominator",
                "estimate", "conf_low", "conf_high")]

## -----------------------------------------------------------------------------
coverage <- estimate_coverage(
  design,
  vaccines = c("BCG", "PENTA1", "PENTA2", "PENTA3", "MCV1"),
  by       = ~health_zone
)
head(coverage)

## -----------------------------------------------------------------------------
estimate_coverage(design, vaccines = c("BCG", "PENTA1", "PENTA3", "MCV1"))

## -----------------------------------------------------------------------------
estimate_zero_dose(design, by = ~stratum)

## -----------------------------------------------------------------------------
estimate_dropout(design, first = "PENTA1", last = "PENTA3", by = ~stratum)

## -----------------------------------------------------------------------------
design_effect(design, c("cov_PENTA1", "cov_PENTA3"))

## -----------------------------------------------------------------------------
report <- vcs_summary(d, design = design, by = ~stratum)
report

## -----------------------------------------------------------------------------
report$coverage

## -----------------------------------------------------------------------------
out_dir <- file.path(tempdir(), "vcs-report")
write_vcs_report(report, out_dir)
list.files(out_dir)

## ----include = FALSE----------------------------------------------------------
unlink(c(log_file, out_dir), recursive = TRUE)

