## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----setup--------------------------------------------------------------------
library(vaxsurvR)

## -----------------------------------------------------------------------------
schedule <- vcs_schedule(
  vaccine               = c("BCG", "PENTA1", "PENTA2", "PENTA3", "MCV1"),
  minimum_age_days      = c(0, 42, 70, 98, 270),
  maximum_age_days      = c(28, 76, 104, 132, 330),
  previous_dose         = c(NA, NA, "PENTA1", "PENTA2", NA),
  minimum_interval_days = c(NA, NA, 28, 28, NA)
)
schedule

## -----------------------------------------------------------------------------
schedule_final_doses(schedule)

## -----------------------------------------------------------------------------
vcs_schedule_who(c("BCG", "PENTA1", "PENTA3", "MCV1"))

## -----------------------------------------------------------------------------
head(vcs_concepts(), 12)

## -----------------------------------------------------------------------------
vcs_dictionary(
  child_id     = "childid",
  household_id = "hh_id",
  interview_id = "hh_id",
  psu          = "cluster",
  age_months   = "child_age_month",
  sex          = "child_sex"
)

## -----------------------------------------------------------------------------
dict <- vcs_dictionary(
  interview_id  = "KEY",
  household_id  = "KEY",
  psu           = "psu_id",
  segment       = "segment_id",
  stratum       = "stratum",
  weight        = "final_weight",
  child_id      = "EC_ID_{c}_{k}",
  child_dob     = "EC_DOB_{c}_{k}",
  sex           = "EC_SEX_{c}_{k}",
  card_seen     = "CARD_{c}_{k}",
  card_status   = "CVH{vv}_{c}_{k}",
  card_date     = "CVH{vv}_date_{c}_{k}",
  recall_status = "VR{vv}_{c}_{k}",
  n_caregivers  = 2,
  n_children    = 2
)
dict

## -----------------------------------------------------------------------------
head(resolve_concept(dict, "card_date", schedule), 8)

## -----------------------------------------------------------------------------
vcs_dictionary(
  card_seen       = "CVH_card_shown",
  yes_values      = c("1", "Oui"),
  no_values       = c("2", "Non"),
  card_yes_values = c("1", "2")   # "yes, dated" and "yes, date incomplete"
)

## -----------------------------------------------------------------------------
tmp <- tempfile(fileext = ".csv")
write.csv(
  data.frame(
    concept = c("child_id", "psu", "card_status"),
    source  = c("EC_ID_{c}_{k}", "psu_id", "CVH{vv}_{c}_{k}")
  ),
  tmp, row.names = FALSE
)
read_vcs_dictionary(tmp, n_caregivers = 2, n_children = 2)
unlink(tmp)

## -----------------------------------------------------------------------------
raw <- vcs_example_raw
dim(raw)
raw[1:3, c("KEY", "psu_id", "stratum", "final_weight")]

## -----------------------------------------------------------------------------
mapped <- map_vcs_variables(vcs_example_raw, vcs_example_dictionary,
                            vcs_example_schedule)
mapped

## -----------------------------------------------------------------------------
subset(derivation_rules(mapped), variable == "child_id")

