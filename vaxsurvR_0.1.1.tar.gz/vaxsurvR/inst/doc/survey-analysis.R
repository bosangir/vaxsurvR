## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----setup--------------------------------------------------------------------
library(vaxsurvR)

## -----------------------------------------------------------------------------
d   <- derive_vaccination_status(vcs_example, evidence = "card_or_recall")
des <- vcs_design(d)
des

## -----------------------------------------------------------------------------
vcs_design(d, ids = ~psu, strata = ~stratum, weights = ~weight)

## -----------------------------------------------------------------------------
no_w <- d
no_w$children$weight <- NULL
no_w$households$weight <- NULL
des_unweighted <- suppressWarnings(vcs_design(no_w))
des_unweighted

## -----------------------------------------------------------------------------
issues(validate_weights(vcs_example))

## -----------------------------------------------------------------------------
check_weight_distribution(vcs_example, by = ~stratum)

## -----------------------------------------------------------------------------
trimmed <- trim_weights(vcs_example, lower = 0.02, upper = 0.98)
c(original = sum(vcs_example$children$weight),
  trimmed  = sum(trimmed$children$weight_trimmed))

## -----------------------------------------------------------------------------
subset(derivation_rules(trimmed), variable == "weight_trimmed")$rule

## -----------------------------------------------------------------------------
design_effect(des, c("cov_BCG", "cov_PENTA1", "cov_PENTA3", "cov_MCV1"))

## -----------------------------------------------------------------------------
lonely <- d
lonely$households$stratum[lonely$households$psu == lonely$households$psu[1]] <- "lonely"

des_lonely <- vcs_design(lonely, lonely_psu = "adjust")
estimate_coverage(des_lonely, vaccines = "BCG")

## -----------------------------------------------------------------------------
estimate_coverage(des, vaccines = "PENTA3", by = ~stratum)

## -----------------------------------------------------------------------------
estimate_coverage(des, vaccines = "BCG", by = c("stratum", "sex"))

## -----------------------------------------------------------------------------
svy <- as_survey_design(des)
survey::svyby(~cov_PENTA3, ~stratum, svy, survey::svymean, na.rm = TRUE)

